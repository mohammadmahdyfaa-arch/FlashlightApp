package com.example.flashlight

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var cameraManager: CameraManager
    private var cameraId: String? = null
    private var isOn = false
    private lateinit var button: Button
    private lateinit var status: TextView

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) toggleFlash()
            else status.text = "مجوز دوربین داده نشد"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager

        cameraId = try {
            cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (_: Exception) {
            null
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(30, 30, 30, 30)
            setBackgroundColor(Color.rgb(25, 28, 38))
        }

        status = TextView(this).apply {
            text = "چراغ‌قوه خاموش است"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        button = Button(this).apply {
            text = "روشن کردن چراغ‌قوه"
            textSize = 18f
            setOnClickListener {
                if (ContextCompat.checkSelfPermission(
                        this@MainActivity, Manifest.permission.CAMERA
                    ) == PackageManager.PERMISSION_GRANTED
                ) toggleFlash()
                else permissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }

        layout.addView(status)
        layout.addView(button)
        setContentView(layout)

        if (cameraId == null) {
            button.isEnabled = false
            status.text = "چراغ‌قوه در این گوشی موجود نیست"
        }
    }

    private fun toggleFlash() {
        val id = cameraId ?: return
        try {
            val newState = !isOn
            cameraManager.setTorchMode(id, newState)
            isOn = newState
            status.text = if (isOn) "چراغ‌قوه روشن است" else "چراغ‌قوه خاموش است"
            button.text = if (isOn) "خاموش کردن چراغ‌قوه" else "روشن کردن چراغ‌قوه"
        } catch (_: Exception) {
            status.text = "خطا در کنترل چراغ‌قوه"
        }
    }

    override fun onDestroy() {
        if (isOn) {
            try {
                cameraId?.let { cameraManager.setTorchMode(it, false) }
            } catch (_: Exception) { }
        }
        super.onDestroy()
    }
}
