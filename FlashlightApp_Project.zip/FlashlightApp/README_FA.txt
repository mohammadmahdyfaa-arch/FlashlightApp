اپلیکیشن ساده چراغ‌قوه اندروید

ساخت APK:
1) فایل ZIP را استخراج کنید.
2) پوشه FlashlightApp را در Android Studio باز کنید.
3) صبر کنید Gradle و Android SDK لازم دانلود/نصب شوند.
4) از منوی Build گزینه Build Bundle(s) / APK(s) > Build APK(s) را بزنید.
5) فایل APK معمولاً در مسیر app/build/outputs/apk/debug/app-debug.apk ساخته می‌شود.

برای استفاده، برنامه را باز کنید و مجوز دوربین را تأیید کنید.
این پروژه در محیط فعلی مستقیماً به APK کامپایل نشده است، چون Android SDK و Gradle در دسترس نبودند.
